<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="css/bootstrap.min (3).css">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<h1>Instagram</h1>
 <div class="card col-sm-6 mx-auto mt-5">
 <h5 class="card-header">Form Tambah</h5>
 <div class="card-body">
 <form action="proses_tambah.php" method="post" enctype="multipart/form-data" autocomplete="off">
  <div class="form-group">
 <label for="">Foto</label>
 <input type="file" class="form-control" name="foto" no="" required><br><br>
 </div>
 <div class="form-group">
 <label for="">Caption</label>
 <input type="text" name="caption" class="form-control" no="" autocomplete="off"><br>
 </div>
 <div class="form-group">
 <label for="">Lokasi</label>
 <input type="text" name="lokasi" class="form-control" no="" autocomplete="off"><br>
 </div>
 <button type="submit" class="btn btn-primary" name="simpan">POST</button>
 </form>
 </div>
 </div>
</body>
</html>