<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
 <title>🍕🍟🥪 𝓓𝓡𝓐𝓚𝓞𝓡 🥙🥡🍖</title>
 <link rel="icon" type="image/x-icon" href="logo.png">
</head>
<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-sarif;
  }

  body {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: gray;
  }

  .container {
    width: 100%;
    display: flex;
    max-width: 850px;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0 30px 25px rgba(0, 0, 0, 0.4);
  }

  .login {
    width: 400px;
  }

  form {
    width: 250px;
    margin: 60px auto;
  }

  h1 {
    margin: 20px;
    text-align: center;
    text-transform: uppercase;
  }

  hr {
    border-top: 2px solid black;
  }

  p {
    text-align: center;
    margin: 10px;
  }

  .right img {
    width: 450px;
    height: 100%;
    border-top-right-radius: 15px;
    border-bottom-right-radius: 15px;
  }

  form label {
    display: block;
    font-size: 16px;
    font-weight: 600;
    padding: 5px;
  }

  input {
    width: 100%;
    margin: 2px;
    border: none;
    outline: none;
    padding: 8px;
    border-radius: 5px;
    border: 1px solid gray;
  }

  button {
    border: none;
    outline: none;
    padding: 8px;
    width: 252px;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    margin-top: 20px;
    border-radius: 5px;
    background: black;
  }

  button:hover {
    background: grey;
  }

  @media (max-width: 880px) {
    .container {
      width: 100%;
      max-width: 750px;
      margin-left: 20px;
      margin-right: 20px;
    }

    form {
      width: 300px;
      margin: 20px auto;
    }

    .login {
      width: 400px;
      padding: 20px;
    }

    button {
      width: 100%;
    }

    .right img {
      width: 100%;
      height: 100%;
    }
  }
</style>
<body>
 <div class="container">
    <div class="login">
      <form action="proses_login.php" method="post">
        <h1>🍟𝓛𝓞𝓖𝓘𝓝🥡</h1>
        <hr><br>
        <input type="text" name="username" placeholder="Username" autocomplete="off"><br><br>
        <input type="password" name="password" placeholder="Password"><br><br>
        <button>Login</button>
      </form>
    </div>
    <div class="right">
      <img src="logo.png" alt="">
    </div>
  </div>
</body>
</html>
